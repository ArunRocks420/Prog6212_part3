# RaceDay: Part 3 (MVC web front end)

ASP.NET Core MVC (.NET 8) application for Organisers and Participants. It uses the Part 2 API for
**all** data and file handling. There is no database access, no Azure SDK and no duplicated business logic here.

## Run with Docker (single command)

```bash
docker build -t raceday-web ./RaceDay.Web && docker run --rm -p 8080:8080 -e ApiBaseUrl=https://YOUR-API-URL raceday-web
```

Then open http://localhost:8080.

If the API runs on your own machine, use `-e ApiBaseUrl=http://host.docker.internal:5000`
(use the port your API listens on, over HTTP, to avoid container certificate issues).

## Run locally

```bash
cd RaceDay.Web
dotnet run
```

Set `ApiBaseUrl` in `appsettings.json` (or as an environment variable) to your running Part 2 API.

## Architecture

| Layer | Files |
|---|---|
| Controllers | `Account`, `Home`, `Organiser`, `Participant` |
| API access | `Services/IRaceDayApi.cs`, `Services/RaceDayApi.cs` (typed HttpClient, adds the JWT from the session) |
| Session and roles | `Helpers/SessionExtensions.cs`, `Helpers/SessionAuthorizeAttribute.cs` |
| Views | `Views/Shared/_Layout` (participant/guest top nav) and `_OrganiserLayout` (sidebar nav), chosen in `_ViewStart` |
| Theme | `wwwroot/css/site.css` on top of Bootstrap 5 |

Blob Storage: banners and profile pictures are posted to the Part 2 API as multipart forms. The API stores them in
Azure Blob Storage and returns a URL, which the MVC views display. The MVC app never talks to Azure.

## Part 2 API endpoints used

Taken from `RaceDay_API_Endpoint_Plan.md`. All calls live in `RaceDay.Web/Services/RaceDayApi.cs`.

| Feature | Call |
|---|---|
| Register / login | `POST api/auth/register`, `POST api/auth/login` (returns `token, userId, role, expiresAt`) |
| Profile | `GET/PUT api/users/me` (the name for the navigation bar is loaded from here after login) |
| Browse events | `GET api/events`, `GET api/events/{id}` (categories nested) |
| Event CRUD | `POST api/events`, `PUT api/events/{id}`, `DELETE api/events/{id}` |
| Categories | `GET/POST api/events/{eventId}/categories`, `DELETE api/categories/{id}` |
| Enrol | `POST api/categories/{categoryId}/enrolments`, `GET api/users/me/enrolments` |
| Organiser enrolments | `GET api/categories/{categoryId}/enrolments` (joined per event in the service) |
| Results | `POST api/enrolments/{id}/result`, `PUT api/results/{id}`, `GET api/events/{id}/results`, `GET api/users/me/results` |

## Additions your Part 2 API needs for Part 3

The endpoint plan does not cover everything the Part 3 brief asks for, so add these to the API:

| Addition | Why |
|---|---|
| `POST api/events/{id}/banner` (multipart field `file`, saves to Azure Blob, stores the URL as `bannerUrl` on the event) | Event banner upload (requirement 5) |
| `POST api/users/me/picture` (multipart field `file`, saves to Azure Blob, returns/stores `profilePictureUrl` on the user) | Profile picture upload |
| `GET api/events/mine` (Organiser only, includes past events) | Organiser dashboard and results entry after an event ends |
| `eventType` and `distanceKM` fields on the event (create, update and read) | Required event fields in the brief |
| `status` on enrolments (Pending, Confirmed, Cancelled) | Colour-coded enrolment statuses |
| Flat enrolment and result objects that include `eventId, eventName, eventDate, categoryName, participantName, bibNumber` (enrolments) and `enrolmentId, eventId` (results) | Display without extra lookups |

Other assumptions: ids are integers, roles are `Organiser` and `Participant`, and `finishTime` is sent as `hh:mm:ss`.
Saved results use status `Finished`. If your API names fields differently, change the DTOs in `Models/ApiModels.cs`.

## Requirements checklist

1. MVC setup: API-only data access (`RaceDayApi`).
2. Auth: register/login via the API, session stores token and role, `[SessionAuthorize]` guards pages, logout clears the session and redirects.
3. Organiser: dashboard, events CRUD with banner upload, categories, enrolments, results entry and publish.
4. Participant: filterable home, event details, enrol, my enrolments, my results ("47th out of 312 finishers"), profile with picture.
5. Azure Blob: handled by the API; MVC only uploads through it.
6. Docker: multi-stage Dockerfile, non-root user, single run command above.
7. UI: Bootstrap, RaceDay theme, colour-coded statuses, friendly errors, consistent styles.
8. CI: `.github/workflows/ci.yml` builds the MVC project and the Docker image.
