using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

/// <summary>
/// Typed HttpClient for the Part 2 API. Adds the session's JWT to every request and
/// turns failures into friendly messages (raw API/exception text never reaches the UI).
///
/// *** If your Part 2 routes differ, change them in this file only. ***
/// </summary>
public class RaceDayApi : IRaceDayApi
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _ctx;
    private readonly ILogger<RaceDayApi> _log;

    public RaceDayApi(HttpClient http, IHttpContextAccessor ctx, ILogger<RaceDayApi> log)
    {
        _http = http; _ctx = ctx; _log = log;
    }

    // ---------- Auth and profile ----------
    public Task<ApiResult<AuthResponse>> LoginAsync(LoginViewModel m) =>
        Send<AuthResponse>(HttpMethod.Post, "api/auth/login",
            JsonContent.Create(new { email = m.Email, password = m.Password }));

    public async Task<ApiResult> RegisterAsync(RegisterViewModel m) =>
        await Send<object>(HttpMethod.Post, "api/auth/register",
            JsonContent.Create(new
            {
                firstName = m.FirstName, lastName = m.LastName, email = m.Email,
                password = m.Password, phoneNumber = m.PhoneNumber ?? "", role = m.Role
            }));

    public Task<ApiResult<ProfileDto>> GetProfileAsync() => Send<ProfileDto>(HttpMethod.Get, "api/users/me");

    public async Task<ApiResult> UpdateProfileAsync(ProfileViewModel m)
    {
        var saved = await Send<object>(HttpMethod.Put, "api/users/me",
            JsonContent.Create(new { firstName = m.FirstName, lastName = m.LastName, phoneNumber = m.PhoneNumber ?? "" }));
        if (!saved.Ok) return saved;

        if (m.Picture is { Length: > 0 })
        {
            // NEW endpoint to add to the API (Azure Blob): POST api/users/me/picture, multipart field "file".
            var up = await Send<object>(HttpMethod.Post, "api/users/me/picture", FileForm(m.Picture));
            if (!up.Ok)
                return new ApiResult { Ok = false, Status = up.Status, Error = "Your details were saved, but the picture could not be uploaded. " + up.Error };
        }
        return saved;
    }

    // ---------- Events ----------
    public Task<ApiResult<List<EventDto>>> GetEventsAsync() => Send<List<EventDto>>(HttpMethod.Get, "api/events");
    public Task<ApiResult<EventDto>> GetEventAsync(int id) => Send<EventDto>(HttpMethod.Get, $"api/events/{id}");

    // NEW endpoint to add to the API: events owned by the logged-in Organiser, including past events.
    public Task<ApiResult<List<EventDto>>> GetMyEventsAsync() => Send<List<EventDto>>(HttpMethod.Get, "api/events/mine");

    public async Task<ApiResult> SaveEventAsync(EventFormViewModel m)
    {
        var body = JsonContent.Create(new
        {
            eventName = m.Name, eventDate = m.Date, location = m.Location, description = m.Description,
            distanceKM = m.Distance, eventType = m.EventType
        });

        ApiResult<EventDto> saved = m.Id == 0
            ? await Send<EventDto>(HttpMethod.Post, "api/events", body)
            : await Send<EventDto>(HttpMethod.Put, $"api/events/{m.Id}", body);
        if (!saved.Ok) return saved;

        if (m.Banner is { Length: > 0 })
        {
            var id = m.Id != 0 ? m.Id : saved.Data?.Id ?? 0;
            if (id == 0)
                return new ApiResult { Ok = false, Error = "The event was saved, but we could not attach the banner. Edit the event to add it." };

            // NEW endpoint to add to the API (Azure Blob): POST api/events/{id}/banner, multipart field "file".
            var up = await Send<object>(HttpMethod.Post, $"api/events/{id}/banner", FileForm(m.Banner));
            if (!up.Ok)
                return new ApiResult { Ok = false, Status = up.Status, Error = "The event was saved, but the banner could not be uploaded. " + up.Error };
        }
        return saved;
    }

    public async Task<ApiResult> DeleteEventAsync(int id) =>
        await Send<object>(HttpMethod.Delete, $"api/events/{id}");

    // ---------- Categories ----------
    public Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId) =>
        Send<List<CategoryDto>>(HttpMethod.Get, $"api/events/{eventId}/categories");

    public async Task<ApiResult> AddCategoryAsync(CategoryFormViewModel m) =>
        await Send<object>(HttpMethod.Post, $"api/events/{m.EventId}/categories",
            JsonContent.Create(new
            {
                categoryName = m.Name, distanceKM = m.DistanceKm,
                entryFee = m.EntryFee ?? 0, maxParticipants = m.MaxParticipants
            }));

    public async Task<ApiResult> DeleteCategoryAsync(int id) =>
        await Send<object>(HttpMethod.Delete, $"api/categories/{id}");

    // ---------- Enrolments ----------
    /// <summary>The API lists enrolments per category, so this joins the lists of an event's categories.</summary>
    public async Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId)
    {
        var ev = await GetEventAsync(eventId);
        if (!ev.Ok || ev.Data is null)
            return new ApiResult<List<EnrolmentDto>> { Ok = false, Status = ev.Status, Error = ev.Error };

        var lookups = await Task.WhenAll(ev.Data.Categories.Select(async c =>
            (Category: c, Result: await Send<List<EnrolmentDto>>(HttpMethod.Get, $"api/categories/{c.Id}/enrolments"))));

        var all = new List<EnrolmentDto>();
        foreach (var (category, result) in lookups)
        {
            if (!result.Ok)
                return new ApiResult<List<EnrolmentDto>> { Ok = false, Status = result.Status, Error = result.Error };

            foreach (var e in result.Data ?? new())
            {
                if (string.IsNullOrEmpty(e.CategoryName)) e.CategoryName = category.Name;
                if (e.CategoryId == 0) e.CategoryId = category.Id;
                if (e.EventId == 0) e.EventId = eventId;
                all.Add(e);
            }
        }
        return new ApiResult<List<EnrolmentDto>> { Ok = true, Status = 200, Data = all };
    }

    public Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync() =>
        Send<List<EnrolmentDto>>(HttpMethod.Get, "api/users/me/enrolments");

    public async Task<ApiResult> EnrolAsync(int categoryId) =>
        await Send<object>(HttpMethod.Post, $"api/categories/{categoryId}/enrolments", JsonContent.Create(new { }));

    // ---------- Results ----------
    public Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId) =>
        Send<List<ResultDto>>(HttpMethod.Get, $"api/events/{eventId}/results");

    /// <summary>New results are POSTed per enrolment; results that already exist are corrected with PUT.</summary>
    public async Task<ApiResult> SaveResultsAsync(IEnumerable<ResultRow> rows)
    {
        foreach (var r in rows)
        {
            var body = JsonContent.Create(new { finishTime = r.FinishTime, position = r.Position, status = "Finished" });
            var res = r.ResultId is > 0
                ? await Send<object>(HttpMethod.Put, $"api/results/{r.ResultId}", body)
                : await Send<object>(HttpMethod.Post, $"api/enrolments/{r.EnrolmentId}/result", body);

            if (!res.Ok)
                return new ApiResult { Ok = false, Status = res.Status, Error = $"The result for {r.ParticipantName} could not be saved. {res.Error}" };
        }
        return new ApiResult { Ok = true, Status = 200 };
    }

    public Task<ApiResult<List<ResultDto>>> GetMyResultsAsync() =>
        Send<List<ResultDto>>(HttpMethod.Get, "api/users/me/results");

    // ---------- Helpers ----------
    private static MultipartFormDataContent FileForm(IFormFile file)
    {
        var form = new MultipartFormDataContent();
        var content = new StreamContent(file.OpenReadStream());
        content.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        form.Add(content, "file", file.FileName);
        return form;
    }

    private async Task<ApiResult<T>> Send<T>(HttpMethod method, string url, HttpContent? content = null)
    {
        try
        {
            using var req = new HttpRequestMessage(method, url) { Content = content };
            var token = _ctx.HttpContext?.Session.GetToken();
            if (!string.IsNullOrEmpty(token))
                req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using var res = await _http.SendAsync(req);
            var body = await res.Content.ReadAsStringAsync();

            if (!res.IsSuccessStatusCode)
            {
                _log.LogWarning("API {Method} {Url} returned {Status}: {Body}", method, url, (int)res.StatusCode, body);
                return new ApiResult<T> { Ok = false, Status = (int)res.StatusCode, Error = Friendly(res.StatusCode, body) };
            }

            T? data = default;
            if (!string.IsNullOrWhiteSpace(body))
            {
                try { data = JsonSerializer.Deserialize<T>(body, Json); }
                catch (JsonException) { /* body not needed for write operations */ }
            }
            return new ApiResult<T> { Ok = true, Status = (int)res.StatusCode, Data = data };
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _log.LogError(ex, "API {Method} {Url} failed", method, url);
            return new ApiResult<T>
            {
                Ok = false,
                Error = "We could not reach the RaceDay service. Please try again in a moment."
            };
        }
    }

    private static string Friendly(HttpStatusCode code, string body)
    {
        // Use a short, human message from the API when it provides one.
        try
        {
            using var doc = JsonDocument.Parse(body);
            foreach (var key in new[] { "message", "error", "detail" })
            {
                if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                    doc.RootElement.TryGetProperty(key, out var p) &&
                    p.ValueKind == JsonValueKind.String &&
                    p.GetString() is { Length: > 0 and < 160 } s)
                    return s;
            }
        }
        catch (JsonException) { }

        return code switch
        {
            HttpStatusCode.BadRequest => "Some of the details are not valid. Check them and try again.",
            HttpStatusCode.Unauthorized => "Your session has expired. Log in again.",
            HttpStatusCode.Forbidden => "You do not have permission to do that.",
            HttpStatusCode.NotFound => "We could not find what you were looking for.",
            HttpStatusCode.Conflict => "That already exists.",
            _ => "Something went wrong on our side. Please try again."
        };
    }
}
