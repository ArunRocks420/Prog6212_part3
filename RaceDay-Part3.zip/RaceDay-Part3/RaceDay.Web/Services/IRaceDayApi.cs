using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

/// <summary>The only way the MVC app touches data: every call goes to the Part 2 API.</summary>
public interface IRaceDayApi
{
    // Auth and profile
    Task<ApiResult<AuthResponse>> LoginAsync(LoginViewModel m);
    Task<ApiResult> RegisterAsync(RegisterViewModel m);
    Task<ApiResult<ProfileDto>> GetProfileAsync();
    Task<ApiResult> UpdateProfileAsync(ProfileViewModel m);

    // Events
    Task<ApiResult<List<EventDto>>> GetEventsAsync();
    Task<ApiResult<EventDto>> GetEventAsync(int id);
    Task<ApiResult<List<EventDto>>> GetMyEventsAsync();
    Task<ApiResult> SaveEventAsync(EventFormViewModel m);
    Task<ApiResult> DeleteEventAsync(int id);

    // Categories
    Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId);
    Task<ApiResult> AddCategoryAsync(CategoryFormViewModel m);
    Task<ApiResult> DeleteCategoryAsync(int id);

    // Enrolments
    Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId);
    Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync();
    Task<ApiResult> EnrolAsync(int categoryId);

    // Results
    Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId);
    Task<ApiResult> SaveResultsAsync(IEnumerable<ResultRow> rows);
    Task<ApiResult<List<ResultDto>>> GetMyResultsAsync();
}
