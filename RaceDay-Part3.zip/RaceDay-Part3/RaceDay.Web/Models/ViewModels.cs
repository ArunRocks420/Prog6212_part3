using System.ComponentModel.DataAnnotations;

namespace RaceDay.Web.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Enter your email address."), EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Enter your password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "Enter your first name."), StringLength(60)]
    public string FirstName { get; set; } = "";

    [Required(ErrorMessage = "Enter your last name."), StringLength(60)]
    public string LastName { get; set; } = "";

    [Required(ErrorMessage = "Enter your email address."), EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = "";

    [Phone(ErrorMessage = "Enter a valid phone number.")]
    public string? PhoneNumber { get; set; }

    [Required(ErrorMessage = "Choose a password."), StringLength(100, MinimumLength = 6, ErrorMessage = "Use at least 6 characters."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Confirm your password."), DataType(DataType.Password), Compare(nameof(Password), ErrorMessage = "The passwords do not match.")]
    public string ConfirmPassword { get; set; } = "";

    [Required(ErrorMessage = "Choose how you will use RaceDay.")]
    public string Role { get; set; } = "Participant";
}

public class EventFormViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Enter the event name."), StringLength(120)]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Add a short description."), StringLength(2000)]
    public string Description { get; set; } = "";

    [Required(ErrorMessage = "Choose the event date and start time.")]
    public DateTime Date { get; set; } = DateTime.Today.AddDays(30).AddHours(7);

    [Required(ErrorMessage = "Enter the location."), StringLength(200)]
    public string Location { get; set; } = "";

    [Range(0.1, 1000, ErrorMessage = "Enter a distance between 0.1 and 1000 km.")]
    public double Distance { get; set; } = 10;

    [Required(ErrorMessage = "Choose an event type.")]
    public string EventType { get; set; } = "Road Run";

    public string? ExistingBannerUrl { get; set; }
    public IFormFile? Banner { get; set; }
}

public class CategoryFormViewModel
{
    public int EventId { get; set; }

    [Required(ErrorMessage = "Enter a category name (for example, 10 km)."), StringLength(80)]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Enter the distance in km."), Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km.")]
    public double? DistanceKm { get; set; }

    [Range(0, 100000, ErrorMessage = "Entry fee cannot be negative.")]
    public decimal? EntryFee { get; set; }

    [Range(1, 100000, ErrorMessage = "Maximum participants must be 1 or more.")]
    public int? MaxParticipants { get; set; }
}

public class ResultRow
{
    public int EnrolmentId { get; set; }
    public int? ResultId { get; set; }
    public string ParticipantName { get; set; } = "";
    public string CategoryName { get; set; } = "";

    [RegularExpression(@"^$|^\d{1,2}:[0-5]\d:[0-5]\d$", ErrorMessage = "Use the format hh:mm:ss.")]
    public string? FinishTime { get; set; }

    [Range(1, 100000, ErrorMessage = "Position must be 1 or higher.")]
    public int? Position { get; set; }
}

public class EventPickerViewModel
{
    public List<EventDto> Events { get; set; } = new();
    public int? EventId { get; set; }
    public string PickerAction { get; set; } = "";
}

public class DashboardViewModel
{
    public List<EventDto> Events { get; set; } = new();
    public List<EventDto> Upcoming { get; set; } = new();
    public int TotalEnrolments { get; set; }
}

public class CategoriesViewModel : EventPickerViewModel
{
    public List<CategoryDto> Categories { get; set; } = new();
    public CategoryFormViewModel Form { get; set; } = new();
}

public class EnrolmentsViewModel : EventPickerViewModel
{
    public List<EnrolmentDto> Enrolments { get; set; } = new();
}

public class ResultsEntryViewModel : EventPickerViewModel
{
    public List<ResultRow> Rows { get; set; } = new();
}

public class HomeIndexViewModel
{
    public List<EventDto> Events { get; set; } = new();
    public string? Search { get; set; }
    public string? Type { get; set; }
    public string? Location { get; set; }
    public double? MaxDistance { get; set; }
    public string? Error { get; set; }
}

public class EventDetailsViewModel
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
}

public class ProfileViewModel
{
    [Required(ErrorMessage = "Enter your first name."), StringLength(60)]
    public string FirstName { get; set; } = "";

    [Required(ErrorMessage = "Enter your last name."), StringLength(60)]
    public string LastName { get; set; } = "";

    public string Email { get; set; } = "";

    [Phone(ErrorMessage = "Enter a valid phone number.")]
    public string? PhoneNumber { get; set; }

    public string? ProfilePictureUrl { get; set; }
    public IFormFile? Picture { get; set; }
}
