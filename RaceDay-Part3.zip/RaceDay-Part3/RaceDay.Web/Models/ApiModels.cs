using System.Text.Json.Serialization;

namespace RaceDay.Web.Models;

// Shapes returned by the Part 2 API (see RaceDay_API_Endpoint_Plan.md).
// [JsonPropertyName] maps the API's field names onto friendlier C# names.

public class AuthResponse
{
    public string Token { get; set; } = "";
    public int UserId { get; set; }
    public string Role { get; set; } = "";
    public DateTime? ExpiresAt { get; set; }
}

public class EventDto
{
    public int Id { get; set; }

    [JsonPropertyName("eventName")] public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    [JsonPropertyName("eventDate")] public DateTime Date { get; set; }
    public string Location { get; set; } = "";

    [JsonPropertyName("distanceKM")] public double? DistanceKm { get; set; }
    [JsonIgnore] public double Distance => DistanceKm ?? 0;

    public string? EventType { get; set; }
    public string? BannerUrl { get; set; }
    public int? OrganiserId { get; set; }

    /// <summary>Filled in by the controllers from the category enrolment lists.</summary>
    public int EnrolmentCount { get; set; }

    /// <summary>GET api/events/{id} returns the categories nested inside the event.</summary>
    public List<CategoryDto> Categories { get; set; } = new();
}

public class CategoryDto
{
    public int Id { get; set; }
    public int? EventId { get; set; }

    [JsonPropertyName("categoryName")] public string Name { get; set; } = "";
    [JsonPropertyName("distanceKM")] public double? DistanceKm { get; set; }
    public decimal? EntryFee { get; set; }
    public int? MaxParticipants { get; set; }
}

public class EnrolmentDto
{
    public int Id { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = "";
    public string ParticipantName { get; set; } = "";
    public int? BibNumber { get; set; }
    public string Status { get; set; } = "Pending";
}

public class ResultDto
{
    public int Id { get; set; }
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = "";
    public string ParticipantName { get; set; } = "";
    public string FinishTime { get; set; } = "";
    public int? Position { get; set; }
    public string Status { get; set; } = "";

    /// <summary>Counted from GET api/events/{id}/results for the "47th out of 312" display.</summary>
    public int TotalFinishers { get; set; }
}

public class ProfileDto
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? PhoneNumber { get; set; }
    public string? ProfilePictureUrl { get; set; }
}

public static class EventTypes
{
    public static readonly string[] All = { "Road Run", "Trail Run", "Cycling", "Triathlon", "Walk" };
}

public class ApiResult
{
    public bool Ok { get; init; }
    public int Status { get; init; }
    public string Error { get; init; } = "";
}

public class ApiResult<T> : ApiResult
{
    public T? Data { get; init; }
}
