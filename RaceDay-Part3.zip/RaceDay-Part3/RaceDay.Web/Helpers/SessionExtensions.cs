using RaceDay.Web.Models;

namespace RaceDay.Web.Helpers;

public static class SessionExtensions
{
    private const string TokenKey = "token";
    private const string RoleKey = "role";
    private const string NameKey = "name";

    public static void SignIn(this ISession s, AuthResponse a)
    {
        s.SetString(TokenKey, a.Token);
        // Normalise the role so every role check in the app compares the same two values.
        s.SetString(RoleKey, a.Role.Equals("organiser", StringComparison.OrdinalIgnoreCase) ? "Organiser" : "Participant");
    }

    public static void SetUserName(this ISession s, string name) => s.SetString(NameKey, name);

    public static string? GetToken(this ISession s) => s.GetString(TokenKey);
    public static string? GetRole(this ISession s) => s.GetString(RoleKey);
    public static string? GetUserName(this ISession s) => s.GetString(NameKey);
    public static bool IsAuthenticated(this ISession s) => !string.IsNullOrEmpty(s.GetString(TokenKey));
}
