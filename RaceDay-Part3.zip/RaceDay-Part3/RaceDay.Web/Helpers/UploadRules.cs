namespace RaceDay.Web.Helpers;

public static class UploadRules
{
    private static readonly string[] Allowed = { ".jpg", ".jpeg", ".png", ".webp" };
    private const long MaxBytes = 2 * 1024 * 1024;

    /// <summary>Returns an error message, or null when the file is fine (or absent).</summary>
    public static string? Validate(IFormFile? file)
    {
        if (file == null || file.Length == 0) return null;
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!Allowed.Contains(ext)) return "Upload a JPG, PNG or WebP image.";
        if (file.Length > MaxBytes) return "Images must be 2 MB or smaller.";
        return null;
    }
}
