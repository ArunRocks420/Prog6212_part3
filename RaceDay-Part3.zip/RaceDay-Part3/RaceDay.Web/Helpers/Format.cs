namespace RaceDay.Web.Helpers;

public static class Format
{
    /// <summary>1 -> 1st, 2 -> 2nd, 11 -> 11th, 47 -> 47th</summary>
    public static string Ordinal(int n)
    {
        var last2 = n % 100;
        if (last2 is >= 11 and <= 13) return n + "th";
        return (n % 10) switch { 1 => n + "st", 2 => n + "nd", 3 => n + "rd", _ => n + "th" };
    }
}
