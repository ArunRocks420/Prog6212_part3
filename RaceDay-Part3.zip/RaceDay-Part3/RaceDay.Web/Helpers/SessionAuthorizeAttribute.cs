using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Web.Helpers;

/// <summary>
/// Blocks unauthenticated users (redirect to login) and users with the wrong role
/// (redirect to Access Denied). Usage: [SessionAuthorize("Organiser")]
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SessionAuthorizeAttribute : ActionFilterAttribute
{
    private readonly string? _role;
    public SessionAuthorizeAttribute(string? role = null) => _role = role;

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        var session = context.HttpContext.Session;

        if (!session.IsAuthenticated())
        {
            context.Result = new RedirectToActionResult("Login", "Account",
                new { returnUrl = context.HttpContext.Request.Path.ToString() });
            return;
        }

        if (_role != null && !string.Equals(session.GetRole(), _role, StringComparison.OrdinalIgnoreCase))
        {
            context.Result = new RedirectToActionResult("AccessDenied", "Home", null);
        }
    }
}
