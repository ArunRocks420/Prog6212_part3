using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize("Organiser")]
public class OrganiserController : Controller
{
    private readonly IRaceDayApi _api;
    public OrganiserController(IRaceDayApi api) => _api = api;

    // ---------- Dashboard ----------
    public async Task<IActionResult> Dashboard()
    {
        var result = await _api.GetMyEventsAsync();
        if (!result.Ok) TempData["Error"] = result.Error;

        var events = (result.Data ?? new()).OrderBy(e => e.Date).ToList();
        await FillEnrolmentCounts(events);
        return View(new DashboardViewModel
        {
            Events = events,
            Upcoming = events.Where(e => e.Date >= DateTime.Today).Take(5).ToList(),
            TotalEnrolments = events.Sum(e => e.EnrolmentCount)
        });
    }

    // ---------- Events ----------
    public async Task<IActionResult> Events()
    {
        var result = await _api.GetMyEventsAsync();
        if (!result.Ok) TempData["Error"] = result.Error;
        var events = (result.Data ?? new()).OrderBy(e => e.Date).ToList();
        await FillEnrolmentCounts(events);
        return View(events);
    }

    [HttpGet]
    public IActionResult Create() => View("EventForm", new EventFormViewModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(EventFormViewModel model)
    {
        var uploadError = UploadRules.Validate(model.Banner);
        if (uploadError != null) ModelState.AddModelError(nameof(model.Banner), uploadError);
        if (!ModelState.IsValid) return View("EventForm", model);

        var result = await _api.SaveEventAsync(model);
        if (!result.Ok)
        {
            ModelState.AddModelError("", result.Error);
            return View("EventForm", model);
        }

        TempData["Success"] = "Event created. Add categories so participants can enrol.";
        return RedirectToAction(nameof(Events));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var result = await _api.GetEventAsync(id);
        if (!result.Ok || result.Data is null)
        {
            TempData["Error"] = "We could not find that event.";
            return RedirectToAction(nameof(Events));
        }

        var e = result.Data;
        return View("EventForm", new EventFormViewModel
        {
            Id = e.Id, Name = e.Name, Description = e.Description, Date = e.Date,
            Location = e.Location, Distance = e.Distance, EventType = e.EventType,
            ExistingBannerUrl = e.BannerUrl
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(EventFormViewModel model)
    {
        var uploadError = UploadRules.Validate(model.Banner);
        if (uploadError != null) ModelState.AddModelError(nameof(model.Banner), uploadError);
        if (!ModelState.IsValid) return View("EventForm", model);

        var result = await _api.SaveEventAsync(model);
        if (!result.Ok)
        {
            ModelState.AddModelError("", result.Error);
            return View("EventForm", model);
        }

        TempData["Success"] = "Event updated.";
        return RedirectToAction(nameof(Events));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _api.DeleteEventAsync(id);
        if (result.Ok) TempData["Success"] = "Event deleted.";
        else TempData["Error"] = result.Error;
        return RedirectToAction(nameof(Events));
    }

    // ---------- Categories ----------
    public async Task<IActionResult> Categories(int? eventId)
    {
        var vm = new CategoriesViewModel { PickerAction = nameof(Categories) };
        await LoadPicker(vm, eventId);
        if (eventId is > 0)
        {
            var cats = await _api.GetCategoriesAsync(eventId.Value);
            vm.Categories = cats.Data ?? new();
            vm.Form.EventId = eventId.Value;
        }
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(CategoryFormViewModel form)
    {
        if (!ModelState.IsValid)
        {
            var vm = new CategoriesViewModel { PickerAction = nameof(Categories), Form = form };
            await LoadPicker(vm, form.EventId);
            vm.Categories = (await _api.GetCategoriesAsync(form.EventId)).Data ?? new();
            return View(nameof(Categories), vm);
        }

        var result = await _api.AddCategoryAsync(form);
        if (result.Ok) TempData["Success"] = "Category added.";
        else TempData["Error"] = result.Error;
        return RedirectToAction(nameof(Categories), new { eventId = form.EventId });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteCategory(int id, int eventId)
    {
        var result = await _api.DeleteCategoryAsync(id);
        if (result.Ok) TempData["Success"] = "Category removed.";
        else TempData["Error"] = result.Error;
        return RedirectToAction(nameof(Categories), new { eventId });
    }

    // ---------- Enrolments ----------
    public async Task<IActionResult> Enrolments(int? eventId)
    {
        var vm = new EnrolmentsViewModel { PickerAction = nameof(Enrolments) };
        await LoadPicker(vm, eventId);
        if (eventId is > 0)
        {
            var result = await _api.GetEventEnrolmentsAsync(eventId.Value);
            if (!result.Ok) TempData["Error"] = result.Error;
            vm.Enrolments = result.Data ?? new();
        }
        return View(vm);
    }

    // ---------- Results ----------
    [HttpGet]
    public async Task<IActionResult> Results(int? eventId)
    {
        var vm = new ResultsEntryViewModel { PickerAction = nameof(Results) };
        await LoadPicker(vm, eventId);
        if (eventId is > 0)
        {
            var enrolments = await _api.GetEventEnrolmentsAsync(eventId.Value);
            if (!enrolments.Ok) TempData["Error"] = enrolments.Error;

            // Pre-fill rows that already have a result so they can be corrected.
            var existing = (await _api.GetEventResultsAsync(eventId.Value)).Data ?? new();
            var byEnrolment = existing.Where(r => r.EnrolmentId > 0)
                .GroupBy(r => r.EnrolmentId).ToDictionary(g => g.Key, g => g.First());

            vm.Rows = (enrolments.Data ?? new())
                .Where(e => !string.Equals(e.Status, "Cancelled", StringComparison.OrdinalIgnoreCase))
                .Select(e =>
                {
                    byEnrolment.TryGetValue(e.Id, out var r);
                    return new ResultRow
                    {
                        EnrolmentId = e.Id,
                        ParticipantName = e.ParticipantName,
                        CategoryName = e.CategoryName,
                        ResultId = r?.Id,
                        FinishTime = r?.FinishTime is { Length: > 8 } t ? t[..8] : r?.FinishTime,
                        Position = r?.Position
                    };
                })
                .ToList();
        }
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Results(ResultsEntryViewModel model)
    {
        model.PickerAction = nameof(Results);
        await LoadPicker(model, model.EventId);

        // Only rows where both a time and a position were entered are published.
        var filled = model.Rows.Where(r => !string.IsNullOrWhiteSpace(r.FinishTime) || r.Position.HasValue).ToList();
        for (var i = 0; i < model.Rows.Count; i++)
        {
            var r = model.Rows[i];
            var hasTime = !string.IsNullOrWhiteSpace(r.FinishTime);
            if (hasTime != r.Position.HasValue)
                ModelState.AddModelError($"Rows[{i}].Position", "Enter both a finish time and a position, or leave both empty.");
        }

        if (filled.Count == 0)
            ModelState.AddModelError("", "Enter at least one finish time and position.");

        if (!ModelState.IsValid || model.EventId is not > 0) return View(model);

        var publish = await _api.SaveResultsAsync(filled);
        if (!publish.Ok)
        {
            ModelState.AddModelError("", publish.Error);
            return View(model);
        }

        TempData["Success"] = "Results published. Participants can now see them.";
        return RedirectToAction(nameof(Results), new { eventId = model.EventId });
    }

    // ---------- Shared ----------
    // The API lists enrolments per category, so counts are gathered per event here.
    private async Task FillEnrolmentCounts(List<EventDto> events)
    {
        var lookups = await Task.WhenAll(events.Select(async e => (Event: e, Result: await _api.GetEventEnrolmentsAsync(e.Id))));
        foreach (var (ev, result) in lookups)
            if (result.Ok)
                ev.EnrolmentCount = (result.Data ?? new()).Count(x => !string.Equals(x.Status, "Cancelled", StringComparison.OrdinalIgnoreCase));
    }

    private async Task LoadPicker(EventPickerViewModel vm, int? eventId)
    {
        var events = await _api.GetMyEventsAsync();
        if (!events.Ok) TempData["Error"] = events.Error;
        vm.Events = (events.Data ?? new()).OrderBy(e => e.Date).ToList();
        vm.EventId = eventId;
    }
}
