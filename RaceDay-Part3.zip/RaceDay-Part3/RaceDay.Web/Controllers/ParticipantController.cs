using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize("Participant")]
public class ParticipantController : Controller
{
    private readonly IRaceDayApi _api;
    public ParticipantController(IRaceDayApi api) => _api = api;

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId <= 0)
        {
            TempData["Error"] = "Choose a category before you enrol.";
            return RedirectToAction("Details", "Home", new { id = eventId });
        }

        var result = await _api.EnrolAsync(categoryId);
        if (!result.Ok)
        {
            TempData["Error"] = result.Error;
            return RedirectToAction("Details", "Home", new { id = eventId });
        }

        TempData["Success"] = "You are enrolled. Check the status below.";
        return RedirectToAction(nameof(MyEnrolments));
    }

    public async Task<IActionResult> MyEnrolments()
    {
        var result = await _api.GetMyEnrolmentsAsync();
        if (!result.Ok) TempData["Error"] = result.Error;
        return View((result.Data ?? new()).OrderBy(e => e.EventDate).ToList());
    }

    public async Task<IActionResult> MyResults()
    {
        var result = await _api.GetMyResultsAsync();
        if (!result.Ok) TempData["Error"] = result.Error;
        var results = (result.Data ?? new()).OrderByDescending(r => r.EventDate).ToList();

        // Count finishers per event so a position can be shown as "47th out of 312".
        var boards = await Task.WhenAll(results.Select(r => r.EventId).Distinct().Select(async id =>
            (EventId: id, Board: await _api.GetEventResultsAsync(id))));
        foreach (var (eventId, board) in boards)
        {
            var finishers = board.Ok ? (board.Data ?? new()).Count(x => x.Position.HasValue) : 0;
            foreach (var r in results.Where(r => r.EventId == eventId)) r.TotalFinishers = finishers;
        }

        return View(results);
    }

    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var result = await _api.GetProfileAsync();
        if (!result.Ok || result.Data is null)
        {
            TempData["Error"] = result.Error;
            return RedirectToAction("Index", "Home");
        }

        return View(new ProfileViewModel
        {
            FirstName = result.Data.FirstName,
            LastName = result.Data.LastName,
            Email = result.Data.Email,
            PhoneNumber = result.Data.PhoneNumber,
            ProfilePictureUrl = result.Data.ProfilePictureUrl
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        var uploadError = UploadRules.Validate(model.Picture);
        if (uploadError != null) ModelState.AddModelError(nameof(model.Picture), uploadError);
        if (!ModelState.IsValid) return View(model);

        var result = await _api.UpdateProfileAsync(model);
        if (!result.Ok)
        {
            ModelState.AddModelError("", result.Error);
            return View(model);
        }

        HttpContext.Session.SetUserName($"{model.FirstName} {model.LastName}".Trim());
        TempData["Success"] = "Profile saved.";
        return RedirectToAction(nameof(Profile));
    }
}
