using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController : Controller
{
    private readonly IRaceDayApi _api;
    public HomeController(IRaceDayApi api) => _api = api;

    public async Task<IActionResult> Index(string? search, string? type, string? location, double? maxDistance)
    {
        var vm = new HomeIndexViewModel { Search = search, Type = type, Location = location, MaxDistance = maxDistance };
        var result = await _api.GetEventsAsync();

        if (!result.Ok)
        {
            vm.Error = result.Error;
            return View(vm);
        }

        // Presentation-only filtering of the list the API already returned.
        var events = (result.Data ?? new()).Where(e => e.Date >= DateTime.Today);
        if (!string.IsNullOrWhiteSpace(search))
            events = events.Where(e => e.Name.Contains(search, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(type))
            events = events.Where(e => string.Equals(e.EventType, type, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(location))
            events = events.Where(e => e.Location.Contains(location, StringComparison.OrdinalIgnoreCase));
        if (maxDistance is > 0)
            events = events.Where(e => e.Distance <= maxDistance);

        vm.Events = events.OrderBy(e => e.Date).ToList();
        return View(vm);
    }

    public async Task<IActionResult> Details(int id)
    {
        var ev = await _api.GetEventAsync(id);
        if (!ev.Ok || ev.Data is null)
        {
            TempData["Error"] = "We could not find that event.";
            return RedirectToAction(nameof(Index));
        }

        // GET api/events/{id} nests the categories; fall back to the categories endpoint if it did not.
        var categories = ev.Data.Categories;
        if (!categories.Any())
            categories = (await _api.GetCategoriesAsync(id)).Data ?? new();

        return View(new EventDetailsViewModel { Event = ev.Data, Categories = categories });
    }

    public IActionResult AccessDenied() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View();
}
