using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class AccountController : Controller
{
    private readonly IRaceDayApi _api;
    public AccountController(IRaceDayApi api) => _api = api;

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (HttpContext.Session.IsAuthenticated()) return RedirectByRole();
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await _api.LoginAsync(model);
        if (!result.Ok || result.Data is null || string.IsNullOrEmpty(result.Data.Token))
        {
            ModelState.AddModelError("", result.Status is 400 or 401
                ? "The email or password is incorrect."
                : (string.IsNullOrEmpty(result.Error) ? "We could not log you in. Please try again." : result.Error));
            return View(model);
        }

        await StartSession(result.Data);

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return LocalRedirect(model.ReturnUrl);

        return RedirectByRole();
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (HttpContext.Session.IsAuthenticated()) return RedirectByRole();
        return View(new RegisterViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (model.Role != "Organiser" && model.Role != "Participant")
            ModelState.AddModelError(nameof(model.Role), "Choose Participant or Organiser.");
        if (!ModelState.IsValid) return View(model);

        var result = await _api.RegisterAsync(model);
        if (!result.Ok)
        {
            ModelState.AddModelError("", result.Error);
            return View(model);
        }

        // Log the new user straight in so they land on the right interface.
        var login = await _api.LoginAsync(new LoginViewModel { Email = model.Email, Password = model.Password });
        if (login.Ok && login.Data is not null && !string.IsNullOrEmpty(login.Data.Token))
        {
            await StartSession(login.Data);
            TempData["Success"] = "Welcome to RaceDay, " + model.FirstName + ".";
            return RedirectByRole();
        }

        TempData["Success"] = "Your account is ready. Log in to continue.";
        return RedirectToAction(nameof(Login));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        TempData["Success"] = "You have been logged out.";
        return RedirectToAction(nameof(Login));
    }

    // The login response has no name, so load it from the profile endpoint for the navigation bar.
    private async Task StartSession(AuthResponse auth)
    {
        HttpContext.Session.SignIn(auth);
        var me = await _api.GetProfileAsync();
        if (me.Ok && me.Data is not null)
            HttpContext.Session.SetUserName($"{me.Data.FirstName} {me.Data.LastName}".Trim());
    }

    private IActionResult RedirectByRole() =>
        HttpContext.Session.GetRole() == "Organiser"
            ? RedirectToAction("Dashboard", "Organiser")
            : RedirectToAction("Index", "Home");
}
